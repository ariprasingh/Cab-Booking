package org.cabbookingweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CabBookingWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
